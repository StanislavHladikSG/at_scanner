/*
 * ©2022 Zebra Technologies LLC. All rights reserved.
 */

#include "ConsoleSampleEventListener.h"
#include "ISO15434formatEnvelope.h"

/* standard C includes */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* standard template library includes */
#include <string>
#include <iostream>
#include <sstream>
#include <errno.h>
#include <cstring>
#include <time.h>
#include <pugixml.hpp>
SampleEventListener::SampleEventListener()
{

}

SampleEventListener::~SampleEventListener()
{
	Close();
}

StatusID SampleEventListener::Open()
{
    StatusID status;
    ::Open(this, SCANNER_TYPE_ALL, &status);
    if(status != STATUS_OK)
    {
        return status;
    }

    std::string inXml = "<inArgs><cmdArgs><arg-int>6</arg-int><arg-int>1,2,4,8,16,32</arg-int></cmdArgs></inArgs>";
    std::string outXml;
    ::ExecCommand(CMD_REGISTER_FOR_EVENTS, inXml, outXml, &status);   
    return status;
}

void SampleEventListener::GetScanners()
{
    unsigned short count;
    vector<unsigned int> list;
    string outXml;
    StatusID eStatus;

    ::GetScanners(&count, &list, outXml, &eStatus);
    
     cout << "================================" << endl;

    if ( eStatus != STATUS_OK )
    {
        std::cout << "Get Scanners failed. Can't connect to the corescanner." << std::endl;
        return ;
    }

    cout << "Get Scanners command success. " << endl << endl;
    cout << "Scanner Count: " << count << endl;
    for(int x=0; x<count; x++)
    {
        cout << "Scanner IDs : " << list[x] << std::endl;
    }
    cout << "Out XML : " << outXml << endl;
    cout << "================================" << endl << endl;
}

void SampleEventListener::GetDeviceTopology()
{
    string inXml;
    string outXml;
    StatusID sId;
    
    cout << "================================" << endl;
    
    ::ExecCommand(CMD_GET_DEVICE_TOPOLOGY, inXml, outXml, &sId);
    
    if(sId == STATUS_OK)
    {
        cout << "Get Device Topology command success. " << endl << endl;
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
        cout<< "Get Device Topology command failed. Error code : " << sId <<endl;
    }    
    
    cout << "================================" << endl << endl;
}

void SampleEventListener::GetAttribute()
{
    std::string scannerID = "";
    cout << "Enter Scanner ID : " << endl;
    cin >> scannerID;
    cout << "Enter attribute number or comma separated attribute numbers : " ;
    std::string attribute_number = "";
    cin >> attribute_number;

    std::string inXml = "<inArgs><scannerID>" + scannerID + 
                        "</scannerID><cmdArgs><arg-xml><attrib_list>" + 
                        attribute_number + "</attrib_list></arg-xml></cmdArgs></inArgs>";
          
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RSM_ATTR_GET, inXml, outXml, &sId);    
    
    cout << "================================" << endl;
    if(sId == STATUS_OK)
    {
        cout << "GetAttribute command success." << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
        cout << "GetAttribute command failed. Error code : " << sId << endl;
    }
    cout << "================================" << endl<< endl;
}

void SampleEventListener::GetAttributeNext()
{
    std::string scannerID = "";
    cout << "Enter Scanner ID : " << endl;
    cin >> scannerID;
    cout << "Enter current attribute number : " ;
    std::string attribute_number = "";
    cin >> attribute_number;

    std::string inXml = "<inArgs><scannerID>" + scannerID + 
                        "</scannerID><cmdArgs><arg-xml><attrib_list>" + 
                        attribute_number + "</attrib_list></arg-xml></cmdArgs></inArgs>";    
    
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RSM_ATTR_GETNEXT, inXml, outXml, &sId);
    
    cout << "================================" << endl;
    
    if(sId == STATUS_OK)
    {
        cout << "GetAttributeNext command success. " << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
         cout << "GetAttributeNext command failed. Error code : " << sId << endl;
    }
    
    cout << "================================" << endl << endl;
}

void SampleEventListener::GetAllAttributes()
{    
    std::string scannerID = "";     
    
    cout << "Enter scanner ID: ";
    cin >> scannerID;
    
    std::string inXml = "<inArgs><scannerID>"+scannerID+"</scannerID></inArgs>";
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RSM_ATTR_GETALL, inXml, outXml, &sId);
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "GetAllAttributes command success. " << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
         cout << "GetAllAttributes command failed. Error code : " << sId << endl;
    }
    cout << "================================" << endl << endl;
}


void SampleEventListener::CreateRtaEventMenu()
{   
    
    cout << "============= RTA ===============" << endl;
    cout << "==== 1. Get Supported RTA Events." << endl;
    cout << "==== 2. Register for RTA Events." << endl;
    cout << "==== 3. Unregister from RTA Events." << endl;
    cout << "==== 4. Get RTA Event Status." << endl;
    cout << "==== 5. Set RTA Event Status." << endl;
    cout << "==== 6. RTA Suspend." << endl;
    cout << "==== 7. Get RTA State." << endl;
    cout << "==== #. Any other to return." << endl;
    cout << "================================" << endl;
    
    std::string rtaMenuSelection = "";     
    
    cout << "Please enter option you want to proceed with: ";
    cin >> rtaMenuSelection;
    
    if (rtaMenuSelection.compare("1") == 0)
    {
        GetSupportedRtaEvents();
    }
    else if (rtaMenuSelection.compare("2") == 0)
    {
        RegisterForRtaEvents();
    }
    else if (rtaMenuSelection.compare("3") == 0)
    {
        UnregisterFormRtaEvents();
    }
    else if (rtaMenuSelection.compare("4") == 0)
    {
        GetRtaEventStatus();
    }
    else if (rtaMenuSelection.compare("5") == 0)
    {
        SetRtaEventStatus();
    }
    else if (rtaMenuSelection.compare("6") == 0)
    {
        SuspendRTAEvent();
    }
    else if (rtaMenuSelection.compare("7") == 0)
    {
        GetRtaState();
    }
}


void SampleEventListener::SuspendRTAEvent()
{  
    std::string scannerID = "";
    std::string enable = "";
    
    cout << "Enter scanner ID: ";
    cin >> scannerID;
    
    cout << "Enter [1] for enable suspend / [0] for disable suspend: ";
    cin >> enable;
    
    if (enable.compare("1") == 0) {
        enable = "true";
    } else if (enable.compare("0") == 0) {
        enable = "false";
    } else {
        cout << "Invalid input";
        return;
    }
    
    std::string inXml = "<inArgs><scannerID>"+scannerID+"</scannerID><cmdArgs><arg-bool>"+enable+"</arg-bool></cmdArgs></inArgs>";
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RTA_SUSPEND_EVENTS, inXml, outXml, &sId);
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Suspend RTA alerts command success. " << endl << endl;

    }
    else
    {
         cout << "Suspend RTA alerts command failed. Error code : " << sId << endl;
    }
    cout << "================================" << endl << endl;
}

void SampleEventListener::GetSupportedRtaEvents()
{  
    std::string scannerID = "";     
    
    cout << "Enter scanner ID: ";
    cin >> scannerID;
    
    std::string inXml = "<inArgs><scannerID>"+scannerID+"</scannerID></inArgs>";
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RTA_GET_SUPPORTED_EVENTS, inXml, outXml, &sId);
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Get Supported RTA Events command success. " << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
         cout << "GetSupportedRtaEvents command failed. Error code : " << sId << endl;
    }
    cout << "================================" << endl << endl;
}

void SampleEventListener::GetRtaEventStatus()
{  
    std::string scannerID = "";     
    
    cout << "Enter scanner ID: ";
    cin >> scannerID;
    
    std::string inXml = "<inArgs><scannerID>"+scannerID+"</scannerID></inArgs>";
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RTA_GET_EVENT_STATUS, inXml, outXml, &sId);
    
    
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Out XML : " << outXml << endl << endl;  
        rtaEventStatusVector = parseRtaEventStatus(outXml);
        
        if (rtaEventStatusVector.size() < 1){
            cout << "Error : GetRtaEventStatus command returned with invalid data" << endl;
            return;
        }
        
        cout << "GetRtaEventStatus command success. " << endl;
        cout << "Available RTA count: " << rtaEventStatusVector.size() << endl << endl;
        
        cout << "=============== RTA Event Status ===============" << endl << endl;  
        for (std::vector<RtaEventStatus>::const_iterator it = rtaEventStatusVector.begin(); it != rtaEventStatusVector.end(); ++it) {
            const RtaEventStatus& event = *it;
            cout << "Event ID: " << event.eventId << endl;
            cout << "Stat: " << event.stat << endl;
            cout << "Scope: " << event.scope << endl;
            cout << "Registered: " << (event.registered ? "true" : "false") << endl;
            cout << "Reported: " << (event.reported ? "true" : "false") << endl;
            cout << "Initialized: " << (event.initialized ? "true" : "false") << endl;
            cout << "Measuring: " << (event.measuring ? "true" : "false") << endl;
            cout << endl;
        }  
    }
    else
    {
         cout << "GetRtaEventStatus command failed. Error code : " << sId << endl;
    }
    cout << "================================================" << endl << endl;
}


void SampleEventListener::SetRtaEventStatus()
{
    std::string scannerID = ""; 
    std::string userInXml = "";

    cout << "Enter scanner ID: ";
    cin >> scannerID;

    std::string inXml_get_event_status = "<inArgs><scannerID>"+scannerID+"</scannerID></inArgs>";
    StatusID sId_get_event_status;
    std::string outXml_get_event_status;
    ::ExecCommand(CMD_RTA_GET_EVENT_STATUS, inXml_get_event_status, outXml_get_event_status, &sId_get_event_status);


    cout << "================================" << endl;    
    if(sId_get_event_status == STATUS_OK)
    {
        rtaEventStatusVector = parseRtaEventStatus(outXml_get_event_status);
        
        if (rtaEventStatusVector.size() < 1){
            cout << "Error : GetRtaEventStatus command returned with invalid data" << endl;
            return;
        }
        
        cout << "Available RTA event count: " << rtaEventStatusVector.size() << endl << endl;
        
        cout << "=============== RTA Event Status ===============" << endl << endl;  
        for (std::vector<RtaEventStatus>::const_iterator it = rtaEventStatusVector.begin(); it != rtaEventStatusVector.end(); ++it) {
            const RtaEventStatus& event = *it;
            cout << "Event ID: " << event.eventId << endl;
            cout << "Stat: " << event.stat << endl;
            cout << "Scope: " << event.scope << endl;
            cout << "Registered: " << (event.registered ? "true" : "false") << endl;
            cout << "Reported: " << (event.reported ? "true" : "false") << endl;
            cout << "Initialized: " << (event.initialized ? "true" : "false") << endl;
            cout << "Measuring: " << (event.measuring ? "true" : "false") << endl;
            cout << endl;
        }  
    }
    else
    {
         cout << "GetRtaEventStatus command failed. Error code : " << sId_get_event_status << endl;
         return;
    }
    cout << "================================================" << endl << endl;

    cout << "You can only modify 'Reported' to 'false' to disable notifications on registered events. "<< endl;
    cout << "To modify the Status Enter attributes seperated by commas( , ). For additional entries seperate the new batch with a colon( : )." << endl;
    cout << "Ex. attrID1,stat1,reported1 : attrID2,stat2,reported2" << endl;

    cin >> userInXml; 
        
    std::string input = userInXml ;
    std::istringstream ss(input);
    std::string token;

    std::string attrId;
    std::string statVal;
    std::string reported_state;;


    std::string inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat><reported>"+reported_state+"</reported></rtaevent>" ;
    std::string completedInXml = "";

    while(std::getline(ss, token, ':')) {
        
        std::istringstream ss2(token);
        std::string token2;
        int index = 0;
        while(std::getline(ss2,token2,',')){
            
            if(index == 0){
                attrId = token2;
                            
            }else if(index == 1){
                statVal = token2 ;
                
            }else if(index == 2){
                reported_state = token2 ;
                inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat><reported>"+reported_state+"</reported></rtaevent>" ;
                
                std::stringstream ss(inXML);
                completedInXml = completedInXml + ss.str();      
            }
            index = index + 1 ;  
        }
    }

    cout << endl << endl;
    
    std::string processed_inXML = "<inArgs><scannerID>"+scannerID+"</scannerID><cmdArgs><arg-xml><rtaevent_list>"+ completedInXml +"</rtaevent_list></arg-xml></cmdArgs></inArgs>"; 
     
    cout << "In XML : " << processed_inXML << endl << endl;

    StatusID sId;    
    std::string outXml;
    ::ExecCommand(CMD_RTA_SET_EVENT_STATUS, processed_inXML, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "RTA Set Event status command success. " << endl << endl;            
    }
    else
    {
        cout << "RTA Set Event status command failed. Error code : " << sId << endl;
    }
    
    cout << "================================" << endl << endl;

}

void SampleEventListener::RegisterForRtaEvents()
{  

    std::string scannerID = "";
    cout << "Enter scanner ID : " << endl;
    cin >> scannerID;
    std::string userInXml = "";
   
    cout << "Enter AttributeID StatValue OnLimit OffLimit seperated by commas. For additional entries seperate the new batch with a semi colon. Ex. attrID1,stat1,onlimit1,offlimit1:attrID2,stat2,onlimit2,offlimit2" << endl;
    cin >> userInXml;
        
    std::string input = userInXml ;
    std::istringstream ss(input);
    std::string token;

    std::string attrId;
    std::string statVal;
    std::string onLimitVal;
    std::string offLimitVal;


    std::string inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat><onlimit>"+onLimitVal+"</onlimit><offlimit>"+offLimitVal+"</offlimit></rtaevent>" ;
    std::string completedInXml = "";

    while(std::getline(ss, token, ':')) {
        
        std::istringstream ss2(token);
        std::string token2;
        int index = 0;
        while(std::getline(ss2,token2,',')){
            
            if(index == 0){
                attrId = token2;
                            
            }else if(index == 1){
                statVal = token2 ;
                            
            }else if(index == 2){
                onLimitVal = token2 ;
                
            }else if(index == 3){
                offLimitVal = token2;
                inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat><onlimit>"+onLimitVal+"</onlimit><offlimit>"+offLimitVal+"</offlimit></rtaevent>" ;
                
                std::stringstream ss(inXML);
                completedInXml = completedInXml + ss.str();
                          
            } 
            
            index = index + 1 ;
            
        }
    }

    std::cout <<  completedInXml  << std::endl;

    std::string processedInXml = "<inArgs><scannerID>"+scannerID+"</scannerID><cmdArgs><arg-xml><rtaevent_list>"+ completedInXml +"</rtaevent_list></arg-xml></cmdArgs></inArgs>";
    
    
    StatusID sId;    
    std::string outXml;
    cout << "In XML  : " << processedInXml << endl << endl;   
    ::ExecCommand(CMD_RTA_REGISTRATION, processedInXml, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "RTA Registration command success. " << endl << endl;            
    }
    else
    {
        cout << "RTA Registration command failed. Error code : " << sId << endl;
    }
    
    cout << "================================" << endl << endl;
   
}

void SampleEventListener::UnregisterFormRtaEvents()
{  
    std::string scannerID = ""; 
    std::string userInXml = "";

    cout << "Enter scanner ID: ";
    cin >> scannerID;

    cout << "To unregister form RTA events Enter AttributeID,StatValue seperated by commas ( , ). For additional entries seperate the new batch with a semi colon ( : )." << endl;
    cout << "Ex. attrID1,stat1:attrID2,stat2" << endl;

    cin >> userInXml; 
        
    std::string input = userInXml ;
    std::istringstream ss(input);
    std::string token;

    std::string attrId;
    std::string statVal;

    std::string inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat></rtaevent>" ;
    std::string completedInXml = "";

    while(std::getline(ss, token, ':')) {
        
        std::istringstream ss2(token);
        std::string token2;
        int index = 0;
        while(std::getline(ss2,token2,',')){
            
            if(index == 0){
                attrId = token2;
                            
            }else if(index == 1){
                statVal = token2 ;
                inXML = "<rtaevent><id>"+attrId+"</id><stat>"+statVal+"</stat></rtaevent>" ;
                
                std::stringstream ss(inXML);
                completedInXml = completedInXml + ss.str();      
            }
            index = index + 1 ;  
        }
    }

    cout << endl << endl;
    
    std::string processed_inXML = "<inArgs><scannerID>"+scannerID+"</scannerID><cmdArgs><arg-xml><rtaevent_list>"+ completedInXml +"</rtaevent_list></arg-xml></cmdArgs></inArgs>"; 
    
    cout << "In XML : " << processed_inXML << endl << endl;

    StatusID sId;    
    std::string outXml;
    ::ExecCommand(CMD_RTA_UN_REGISTRATION, processed_inXML, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "RTA Event Unregirtration command success. " << endl << endl;            
    }
    else
    {
        cout << "RTA Event Unregirtration command failed. Error code : " << sId << endl;
    }
    
    cout << "================================" << endl << endl;


}


void SampleEventListener::SetAttribute()
{
    std::string scannerID = "";
    cout << "Enter scanner ID : " << endl;
    cin >> scannerID;
    std::string attributeNumber = "";
    cout << "Enter attribute number : " << endl;
    cin >> attributeNumber;
    std::string dataType = "";
    cout << "Enter data type : " << endl;
    cin >> dataType;
    std::string attributeValue = "";
    cout << "Enter attribute value : " << endl;
    cin >> attributeValue;
    
    std::string inXml = "<inArgs><scannerID>"+ scannerID +
                        "</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>" + attributeNumber + 
                        "</id><datatype>" + dataType + 
                        "</datatype><value>" + attributeValue + 
                        "</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>";
    
    StatusID sId;    
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;   
    ::ExecCommand(CMD_RSM_ATTR_SET, inXml, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "SetAttribute command success. " << endl << endl;            
    }
    else
    {
         cout << "SetAttribute command failed. Error code : " << sId << endl;
    }
    
    cout << "================================" << endl << endl;

}

void SampleEventListener::SetAttributeStore()
{
    std::string scannerID = "";
    cout << "Enter scanner ID : " << endl;
    cin >> scannerID;
    std::string attributeNumber = "";
    cout << "Enter attribute number : " << endl;
    cin >> attributeNumber;
    std::string dataType = "";
    cout << "Enter data type : " << endl;
    cin >> dataType;
    std::string attributeValue = "";
    cout << "Enter attribute value : " << endl;
    cin >> attributeValue;    

    std::string inXml = "<inArgs><scannerID>"+ scannerID +
                        "</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>" + attributeNumber + 
                        "</id><datatype>" + dataType + 
                        "</datatype><value>" + attributeValue + 
                        "</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>";
    
    StatusID sId;    
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl; 
    ::ExecCommand(CMD_RSM_ATTR_STORE, inXml, outXml, &sId);
   
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "StoreAttribute command success. " << endl << endl;               
    }
    else
    {
         cout << "StoreAttribute command failed. Error code : " << sId << endl;
    }    
    cout << "================================" << endl << endl;
}

void SampleEventListener::SetZeroWeight()
{
    std::string inXml = "<inArgs><scannerID>1</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>6019</id><datatype>X</datatype><value>0</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>";

    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;     
    ::ExecCommand(CMD_RSM_ATTR_SET, inXml, outXml, &sId);
      
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "SetZeroWeight command success. " << endl << endl;          
    }
    else
    {
         cout << "SetZeroWeight command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;
}

//Event EventListener for get Get Version number of Core scanner
void SampleEventListener::GetVersion() {
    
    std::string inXml = "<inArgs></inArgs>";   
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_GET_VERSION, inXml, outXml, &sId);
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "GetVersion command success. " << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
         cout << "GetVersion command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;    
}

void SampleEventListener::Close()
{
    StatusID status;
    ::Close(0, &status);

}

string getStringFromRawData(unsigned char* rawData,int startIndex, int endIndex){
    int numElements = endIndex-startIndex;
    char buffer [numElements];
    int j=0;
    for(int i=startIndex;i<endIndex;i++){
        sprintf (&buffer[j++], "%c", rawData[i]);
    }
    string str(buffer);
    return str;
}
void SampleEventListener::OnImageEvent( short eventType, int size, short imageFormat, char* sfimageData, int dataLength, std::string& pScannerData )
{
	cout << "OnImageEvent" << endl;
}

void SampleEventListener::OnBinaryDataEvent( short eventType, int size, short dataFormat, unsigned char* sfBinaryData, std::string&  pScannerData)
{    
     // Constants for ISO15434 messages
        const unsigned char ISO_RS = 0x1E;  // ISO15454 Format Trailer Character
//        const unsigned char ISO_GS = 0x1D;  // ISO15454 Data Element Separator
        const unsigned char ISO_EOT = 0x04;  // ISO15454 Message Trailer Character
        const unsigned char MSG_EASYCAP = 0;     // ISO15451 Message DocCap message number
        FILE *imgFile; 
     	cout << "OnBinaryDataEvent" << endl;
		
        int packetLength = (sfBinaryData[0] << 24) |
                        (sfBinaryData[1] << 16) |
                        (sfBinaryData[2] << 8) |
                        sfBinaryData[3];
        
        if(packetLength+4!= size)
        {
            cout << "Incorrect packet size\n" << endl;
        }
        else
        {
            if(sfBinaryData[4]!= MSG_EASYCAP)
            {
                cout << "Incorrect Msg type\n" << endl;
            }
            else
            {
                // ISO15434 Envelope: is message header correct?
                if ((sfBinaryData[5] != '[') || (sfBinaryData[6] != ')') || (sfBinaryData[7] != '>') || (sfBinaryData[8] != ISO_RS))
                {
                    cout << "Incorrect message header\n" << endl;
                }
                else
                {
                     // ISO15434 Envelope: is message header correct?
                    if (sfBinaryData[size - 1] != ISO_EOT)
                    {
                        cout << "Incorrect message header ISO_EOT\n" << endl;
                    }
                    else
                    {
                        cout << "Correct packet received \n" << endl;
                        ISO15434formatEnvelope *anEnvelope = new ISO15434formatEnvelope(sfBinaryData,size, 9);
                        while (anEnvelope->getNext())
                        {
                            string fileType = anEnvelope->getFileType();

                            if (fileType == "BarCode")
                            {
                                string decodeData=getStringFromRawData(sfBinaryData,anEnvelope->getDataIndex(),anEnvelope->getDataIndex()+anEnvelope->getDataLength());
                                cout << "Barcode received " << endl;
                                cout << " Data type = "<<  (int)decodeData.at(0) << endl;
                                cout << " Data = "<< decodeData.substr(1,anEnvelope->getDataLength())<< endl;
                            }else{
                                char filename[200];
                                string fileFormat = anEnvelope->getFileType();
                                time_t t = time(0);   // get time now
                                tm* now = localtime(&t);
                                sprintf(filename,"ZIMG-%d%d%d%d%d%d%s%s", now->tm_year + 1900, now->tm_mon + 1,now->tm_mday,now->tm_hour,now->tm_min,now->tm_sec,".",fileFormat.c_str());
                                imgFile = fopen(filename, "w");
                                if (!imgFile)
                                {
                                    cout << "Unable to open file " << filename<< endl;
                                    continue;
                                }
                                fwrite(&sfBinaryData[anEnvelope->getDataIndex()]+6,sizeof(unsigned char),anEnvelope->getDataLength()+6,imgFile);
                                fflush(imgFile);
                                fclose (imgFile);
                                cout << "ImageData saved in " <<filename<< endl;
                            }
                        }
                    }
                }
                
            }
        }
}

void SampleEventListener::OnVideoEvent( short eventType, int size, char* sfvideoData, int dataLength, std::string& pScannerData )
{
	cout << "OnVideoEvent" << endl;
}

void SampleEventListener::OnPNPEvent( short eventType, std::string ppnpData )
{
    string str;
    if (eventType == SCANNER_ATTACHED) {
        cout << "Scanner attached" << endl;
        str = ppnpData;
    } else if (eventType == SCANNER_DETACHED) {
        cout << "Scanner detached" << endl;
        str =  ppnpData;
    } else {
        str = " UNKNOWN PNP Event ";
    }
    cout << str << endl;
}

void SampleEventListener::OnCommandResponseEvent( short status, std::string& prspData )
{
    cout << endl << "Scanner data: " << prspData << endl;
	cout << "OnCommandResponseEvent" << endl;
	cout << prspData << endl;
}

void SampleEventListener::OnScannerNotification( short notificationType, std::string& pScannerData )
{
    cout << endl << "Scanner event data: " << pScannerData << endl;
	cout << "OnScannerNotification" << endl;
}

void SampleEventListener::OnIOEvent( short type, unsigned char data )
{
	cout << "OnIOEvent" << endl;
}

void SampleEventListener::OnScanRMDEvent( short eventType, std::string& prmdData )
{
	cout << "OnScanRMDEvent" << endl;
        cout << "Out XML " << endl;
        cout << prmdData << endl;
}

void SampleEventListener::OnDisconnect()
{
	cout << "OnDisconnect" << endl;
}

void SampleEventListener::OnBarcodeEvent(short int eventType, std::string & pscanData)
{
	cout << "Barcode Detected" << endl;
	cout << "Out XML" << endl;
	cout << pscanData << endl;
}

void SampleEventListener::RebootScanner()
{
    
}

void SampleEventListener::FirmwareUpdate()
{
    std::string inXml;
    std::string outXml;
    std::string datFilePath; 
    StatusID sId;
    std::string scannerID;
    std::string bulkOption;
    
    std::cout << "Enter Scanner ID : " << std::endl;
    std::cin >> scannerID;
    std::cout << "Enter Firmware DAT file path: " << std::endl;
    std::cin >> datFilePath;
    std::cout << "Enter USB communication mode 1=hid, 2=bulk : ";
    std::cin >> bulkOption;
    
    inXml = "<inArgs><scannerID>" + scannerID + "</scannerID><cmdArgs><arg-string>" + datFilePath + "</arg-string><arg-int>" + bulkOption + "</arg-int></cmdArgs></inArgs>";
    cout << "In XML  : " << inXml << endl << endl;     
    ::ExecCommand(CMD_DEVICE_UPDATE_FIRMWARE, inXml, outXml, &sId);
        
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Firmware Update command success. " << endl << endl;              
    }
    else
    {
         cout << "Firmware Update command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;    
}

void SampleEventListener::FirmwareUpdateFromPlugin()
{
     std::string inXml;
    std::string outXml;
    std::string pluginFilePath=""; 
    StatusID sId;
    std::string scannerID;
    std::string bulkOption;
    
    std::cout << "Enter Scanner ID : " << std::endl;
    std::cin >> scannerID;
    std::cout << "Enter Firmware Plug-in file path: " << std::endl;
    //std::cin >>  pluginFilePath;

    while ( pluginFilePath.size() < 4 ){
        std::getline(std::cin, pluginFilePath);
    }
    
    if ( !(pluginFilePath.substr(pluginFilePath.find_last_of(".")+ 1) == "SCNPLG") ){
        std::cout << "Please Enter a file with extension .SCNPLG." << std::endl << std::endl;
        return;
    }
    
    std::cout << "Enter USB communication mode 1=hid, 2=bulk : ";
    std::cin >> bulkOption;
    
    inXml = "<inArgs><scannerID>" + scannerID + "</scannerID><cmdArgs><arg-string>" + pluginFilePath + "</arg-string><arg-int>" + bulkOption + "</arg-int></cmdArgs></inArgs>";
    cout << "In XML  : " << inXml << endl << endl; 
    ::ExecCommand(CMD_DEVICE_UPDATE_FIRMWARE_FROM_PLUGIN, inXml, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "FirmwareUpdate From Plug-in command success. " << endl << endl;              
    }
    else
    {
         cout << "FirmwareUpdate From Plug-in command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;
}

void SampleEventListener::StartNewFirmware()
{
    std::string inXml;
    std::string outXml;
    StatusID sId;
    std::string scannerID;
    
    std::cout << "Enter Scanner ID : " << std::endl;
    std::cin >> scannerID;
       
    inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>"; 
    cout << "In XML  : " << inXml << endl << endl;   
    ::ExecCommand(CMD_START_NEW_FIRMWARE, inXml, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Start New Firmware command success. " << endl << endl;            
    }
    else
    {
         cout << "Start New Firmware command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;
}

void SampleEventListener::AbortFirmwareUpdate()
{
    std::string inXml;
    std::string outXml;
    StatusID sId;
    std::string scannerID;    
   
    std::cout << "Enter Scanner ID : " << std::endl;
    std::cin >> scannerID;
    
    inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>";
    cout << "In XML  : " << inXml << endl << endl; 
    ::ExecCommand(CMD_DEVICE_ABORT_UPDATE_FIRMWARE, inXml, outXml, &sId);
    
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Abort Firmware Update command success. " << endl << endl;              
    }
    else
    {
         cout << "Abort Firmware Update command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;
}

/**
 * Method to execute action attribute related commands.
 * added to v1.3.0 release.
 * @param opCode
 */
void SampleEventListener::ExecuteActionCommand(CmdOpcode opCode)
{
    std::string scannerID = "";
    std::string ledNumber = "";
    std::string beeperCode = "";
    std::string inXml;
    std::string commandName = "";
           
    switch (opCode)
    {
        case CMD_DEVICE_LED_ON:
        case CMD_DEVICE_LED_OFF:
        {
            commandName = "Device LED ON/OFF command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            cout << "Enter LED number : ";
            cin >> ledNumber;

            inXml = "<inArgs><scannerID>" + scannerID + 
                                "</scannerID><cmdArgs><arg-int>" + ledNumber +
                                "</arg-int></cmdArgs></inArgs>";
            break;
        }
        case CMD_DEVICE_BEEP_CONTROL:
        {
            commandName = "Beep command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            cout << "Enter Beeper code : ";
            cin >> beeperCode;

            inXml = "<inArgs><scannerID>" + scannerID + 
                                "</scannerID><cmdArgs><arg-int>" + beeperCode +
                                "</arg-int></cmdArgs></inArgs>";
            break;
        }
        case CMD_DEVICE_SCAN_ENABLE:
        case CMD_DEVICE_SCAN_DISABLE:
        {
            commandName = "Device Scan Enable/Disable command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>";
            break;
        }
        case CMD_REBOOT_SCANNER:
        {
            commandName = "Reboot scanner command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>";
            break;
        }
        case CMD_DEVICE_AIM_ON:
        case CMD_DEVICE_AIM_OFF:
        {
            commandName = "Device AIM ON/OFF command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>";
            break;
        }
        case CMD_LOAD_CONFIGURATION:
        {
            std::string config_file_path = "";
            commandName = "Configuration update ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            cout << "Enter configuration file path : ";
            cin.ignore();
            std::getline(std::cin, config_file_path);

            inXml = "<inArgs><scannerID>" + scannerID + "</scannerID>" + 
                    "<cmdArgs><arg-string>" + config_file_path + "</arg-string></cmdArgs>" +
                    "</inArgs>";
            break;
        }
        case CMD_KEYBOARD_EMULATOR_ENABLE:
        {
            std::string input_enable_or_disable = "";
            commandName = "Keyboard Emulator Enable/Disable ";
            cout << "Enter 1 to Enable, 0 to Disable : ";
            cin.ignore();
            std::getline(std::cin, input_enable_or_disable);
            
            if (strcmp(input_enable_or_disable.c_str(), "1") == 0) {
                input_enable_or_disable = "true";
            } else {
                input_enable_or_disable = "false";
            }
            
            inXml = "<inArgs><cmdArgs><arg-bool>" + input_enable_or_disable +
                    "</arg-bool></cmdArgs></inArgs>";
            break;
        }
        default:
        {
            commandName = "Default Action command ";
            cout << "Enter scanner ID : ";
            cin >> scannerID;
            inXml = "<inArgs><scannerID>" + scannerID + "</scannerID></inArgs>";
            break;
        }
    }
      
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl; 
    ::ExecCommand(opCode, inXml, outXml, &sId);

    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << commandName << "success. " << endl << endl;              
    }
    else
    {
         cout << commandName << "failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;
}

/**
 * Method to execute switch host mode command (option 20).
*/
void SampleEventListener::SwitchHostMode()
{
    std::string scannerID = "";
    cout << "Enter scanner ID : ";
    cin >> scannerID;
    std::string hostMode = "";
    cout << "Host mode options : " << endl;
    cout << "   1. USB-HIDKB " << endl;
    cout << "   2. USB-SNAPI with imaging " << endl;
    cout << "   3. USB-SNAPI without imaging " << endl;
    cout << "   4. USB-IBMHID " << endl;
    cout << "   5. USB-IBMTT " << endl;
    cout << "Enter host mode to switch into (1-5): ";
    cin >> hostMode;
    std::string hostModeString = "";
    int hostModeInteger = atoi(hostMode.c_str());
    switch (hostModeInteger)
    {
        case 1:
        {
            hostModeString = "XUA-45001-3";
            break;
        }  
        case 2:
        {
            hostModeString = "XUA-45001-9";
            break;
        }
        case 3:
        {
            hostModeString = "XUA-45001-10";
            break;
        } 
        case 4:
        {
            hostModeString = "XUA-45001-1";
            break;
        } 
        case 5:
        {
            hostModeString = "XUA-45001-2";
            break;
        } 
        default:
        {
            cout << "=================================" << endl;
            cout << "Error : Invalid value entered!!!"  << endl;
            cout << "=================================" << endl<< endl;
            return;
        }
    }
    
    std::string inXml = "<inArgs><scannerID>"+ scannerID +"</scannerID><cmdArgs>"
                        "<arg-string>"+ hostModeString +"</arg-string>"
                        "<arg-bool>FALSE</arg-bool><arg-bool>TRUE</arg-bool></cmdArgs></inArgs>";
    
    StatusID sId;    
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;   
    ::ExecCommand(CMD_DEVICE_SWITCH_HOST_MODE, inXml, outXml, &sId);
    
    cout << "==================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "Switch host mode command success. " << endl;            
    }
    else
    {
         cout << "Switch host mode command failed. Error code : " << sId << endl;
    }
    
    cout << "==================================" << endl << endl;

}

//Event EventListener for get HIDKB simulation settings XML
void SampleEventListener::HidkbBSimulationGetXml() {
    
    std::string inXml = "<inArgs></inArgs>";   
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_KEYBOARD_EMULATOR_GET_XML, inXml, outXml, &sId);
       
    cout << "================================" << endl;    
    if(sId == STATUS_OK)
    {
        cout << "HIDKB simulation get XML command success. " << endl << endl;        
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
         cout << "HIDKB simulation get XML command failed. Error code : " << sId << endl;
    } 
    cout << "================================" << endl << endl;    
}


std::vector<SampleEventListener::RtaEventStatus> SampleEventListener::parseRtaEventStatus(const std::string& outXml) {
    std::vector<RtaEventStatus> rtaEventStatusVector;
    
    pugi::xml_document doc;
    if (!doc.load_string(outXml.c_str())) {
        cerr << "Failed to parse XML" << endl;
        return rtaEventStatusVector;
    }

    for (pugi::xml_node rtaevent = doc.child("outArgs").child("arg-xml").child("response").child("rtaevent_list").child("rtaevent");
         rtaevent;
         rtaevent = rtaevent.next_sibling("rtaevent")) {

        RtaEventStatus status;
        status.eventId = rtaevent.child("id").text().as_int();
        status.stat = rtaevent.child("stat").text().as_int();
        status.scope = rtaevent.child("scope").text().as_int();
        status.registered = std::string(rtaevent.child("registered").child_value()) == "TRUE";
        status.reported = std::string(rtaevent.child("reported").child_value()) == "TRUE";
        status.initialized = std::string(rtaevent.child("initialized").child_value()) == "TRUE";
        status.measuring = std::string(rtaevent.child("measuring").child_value()) == "TRUE";

        rtaEventStatusVector.push_back(status);
    }

    return rtaEventStatusVector;
}

void SampleEventListener::GetRtaState()
{
    std::string scannerID = "";

    cout << "Enter scanner ID: ";
    cin >> scannerID;

    std::string inXml = "<inArgs><scannerID>"+scannerID+"</scannerID></inArgs>";
    StatusID sId;
    std::string outXml;
    cout << "In XML  : " << inXml << endl << endl;
    ::ExecCommand(CMD_RTA_STATE, inXml, outXml, &sId);

    cout << "================================" << endl;
    if(sId == STATUS_OK)
    {
        cout << "GetRtaState command success. " << endl << endl;
        cout << "Out XML : " << outXml << endl;
    }
    else
    {
        cout << "GetRtaState command failed. Error code : " << sId << endl;
    }
    cout << "================================" << endl << endl;
}