/*
 * ©2022 Zebra Technologies LLC. All rights reserved.
 */

#ifndef SAMPLEEVENTLISTENER_H_
#define SAMPLEEVENTLISTENER_H_



#include "CsIEventListenerXml.h"
#include "CsUserDefs.h"
#include "CsBarcodeTypes.h"
#include "Cslibcorescanner_xml.h"

/* standard C includes */
#include <stdio.h>
#include <stdlib.h>

/* standard template library includes */
#include <string>
#include <iostream>
#include <sstream>

using namespace std;

class SampleEventListener : public IEventListenerXml
{
public:
    
    /**
     * Struct to hold RTA event values
     */
    struct RtaEventStatus {
        int eventId; // 1st & 2nd Bytes
        int stat;    // 3rd & 4th Bytes
        int scope;   // 5th & 6th Bytes 
        bool registered;    // 0 - bit position
        bool reported;      // 1 - bit position
        bool initialized;   // 2 - bit position
        bool measuring;     // 3 - bit position
    };
    
    std::vector<RtaEventStatus> rtaEventStatusVector;
    
	explicit SampleEventListener();
	virtual ~SampleEventListener();

    virtual void OnImageEvent( short eventType, int size, short imageFormat, char* sfimageData, int dataLength, std::string& pScannerData );
    virtual void OnVideoEvent( short eventType, int size, char* sfvideoData, int dataLength, std::string& pScannerData );
    virtual void OnBarcodeEvent( short eventType, std::string& pscanData );
    virtual void OnPNPEvent( short eventType, std::string ppnpData );
    virtual void OnCommandResponseEvent( short status, std::string& prspData );
    virtual void OnScannerNotification( short notificationType, std::string& pScannerData );
    virtual void OnIOEvent( short type, unsigned char data );
    virtual void OnScanRMDEvent( short eventType, std::string& prmdData );
    virtual void OnDisconnect();
    virtual void OnBinaryDataEvent( short eventType, int size, short dataFormat, unsigned char* sfBinaryData, std::string&  pScannerData);


    StatusID Open();
    void GetScanners();
    void GetAttribute();
    void GetAttributeNext();
    void GetAllAttributes();
    void SetAttribute();
    void SetAttributeStore();
    void SetZeroWeight();
    void Close();
    
    void RebootScanner();
    void ExecuteActionCommand(CmdOpcode opCode);
    void GetDeviceTopology();
    void FirmwareUpdate();
    void FirmwareUpdateFromPlugin();
    void StartNewFirmware();
    void AbortFirmwareUpdate();
    void GetVersion();
    void SwitchHostMode();
    void HidkbBSimulationGetXml();
    void GetSupportedRtaEvents();
    void RegisterForRtaEvents();
    void UnregisterFormRtaEvents();
    void CreateRtaEventMenu();
    void SuspendRTAEvent();
    void GetRtaEventStatus();
    void SetRtaEventStatus();
    void GetRtaState();
    
    /**
     * Read the RTA Event Status out string and push events into rtaEventStatusVector
     */
    std::vector<RtaEventStatus> parseRtaEventStatus(const std::string& outXml);

};


#endif /* SAMPLEEVENTLISTENER_H_ */
