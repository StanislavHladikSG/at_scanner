/* 
 * File:   xml_formatter.cpp
 *
 * Created on July 1, 2016, 9:48 AM
 * Simple tokenizer to format xml.
 */

#include "xml_formatter.h"
#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <bitset>

using namespace std;

typedef struct tag_xml_token {
    int iTokenType;
    std::string strValue;
} xml_token;


// xml token engine status //
enum xml_token_states{
    XML_TOKEN_STATE_ZERO ,
    XML_TOKEN_STATE_ONE ,
    XML_TOKEN_STATE_TWO,
    XML_TOKEN_STATE_THREE ,
    XML_TOKEN_STATE_FOUR,
    XML_TOKEN_STATE_FIVE,
    XML_TOKEN_STATE_SIX,
    XML_TOKEN_STATE_SEVEN,
    XML_TOKEN_STATE_EIGHT
};

// xml token types //
enum xml_token_types {
    XML_TOKEN_TYPE_START_TAG,
    XML_TOKEN_TYPE_END_TAG,
    XML_TOKEN_TYPE_DATA,
    XML_TOKEN_TYPE_INVALID=-1
};

static std::vector<xml_token>  break_xml_into_tokens(std::string inXml )
{
    int state = XML_TOKEN_STATE_ZERO;
    
    std::vector <xml_token> _return ;
    xml_token tokenCurrent;
    std::string strCurrentValue;
    int iCurrentTokenType = -1;
    int iCurrentPosition = 0;
    bool bIsFirstTime = true ;
    
    while( iCurrentPosition < inXml.length() ){

        switch ( state ){
            case XML_TOKEN_STATE_ZERO:
            {
                char cCurrent = inXml [ iCurrentPosition++ ];
                if ( cCurrent == '<' ){
                    iCurrentTokenType = XML_TOKEN_TYPE_START_TAG;
                    strCurrentValue = "";
                    state = XML_TOKEN_STATE_ONE;
                }else if ( cCurrent == ' ' || cCurrent == '\t' || cCurrent == '\n'){
                    iCurrentTokenType = XML_TOKEN_TYPE_INVALID;
                }else{
                    iCurrentTokenType = XML_TOKEN_TYPE_DATA;
                    strCurrentValue = "";
                    iCurrentPosition-- ;
                    state = XML_TOKEN_STATE_FIVE;
                }           
            }
            break;
            
            case XML_TOKEN_STATE_ONE:
            {
                char cCurrent = inXml [iCurrentPosition++];
                if ( cCurrent =='/' ){
                    strCurrentValue = "" ;
                    state = XML_TOKEN_STATE_TWO;
                    iCurrentTokenType = XML_TOKEN_TYPE_END_TAG;
                }else if ( cCurrent == '>'){
                    tokenCurrent.iTokenType = iCurrentTokenType;
                    tokenCurrent.strValue = strCurrentValue;
                    _return.push_back(tokenCurrent);
                    state = XML_TOKEN_STATE_ZERO;
                    iCurrentTokenType =XML_TOKEN_TYPE_INVALID;   
                /*else if ( cCurrent == ' ' || cCurrent == '\t' || cCurrent == '\n'){*/
                    // :DO NOTHING: //
                }else {
                    state = XML_TOKEN_STATE_SEVEN;
                    strCurrentValue.append(1, cCurrent);
                }
            }
            break;
            
            case XML_TOKEN_STATE_TWO:
            {
                char cCurrent = inXml [iCurrentPosition++];
                if (  cCurrent == ' ' || cCurrent == '\n' || cCurrent == '\t'){
                    // :DO NOTHING://
                }else {
                    state = XML_TOKEN_STATE_EIGHT;
                    strCurrentValue.append(1,cCurrent);
                }
            }
            break;
            
            case XML_TOKEN_STATE_THREE:
            {
                std::cout << "Unused token state. This line could ever reach." <<std::endl;
                exit(0);
            }
         
            case XML_TOKEN_STATE_FOUR:
            {
                std::cout << "Un-used state. This line could never reach."<< std::endl;
                exit(0);
            }
          
            case XML_TOKEN_STATE_FIVE:
            {
                char cCurrent = inXml [iCurrentPosition++];
                if ( cCurrent == '<' ){
                    tokenCurrent.iTokenType = iCurrentTokenType;
                    tokenCurrent.strValue = strCurrentValue;
                    _return.push_back(tokenCurrent);
                    bIsFirstTime = true;
                    iCurrentPosition--;
                    state = XML_TOKEN_STATE_ZERO;
                    iCurrentTokenType = XML_TOKEN_TYPE_INVALID;
                    
                }else{
                    iCurrentTokenType = XML_TOKEN_TYPE_DATA;
                    if (  bIsFirstTime  ){
                        strCurrentValue =  "" ;
                        bIsFirstTime = false ;
                    }
                    strCurrentValue.append(1,cCurrent);
                }
            }
            break;
            case XML_TOKEN_STATE_SIX:
                std::cout << "Unused state , this state could never reach"<< std::endl;
                exit(0);
               
            case XML_TOKEN_STATE_SEVEN:
            {
                char cCurrent = inXml [iCurrentPosition++];
                if ( cCurrent == '>' ){
                    tokenCurrent.iTokenType = iCurrentTokenType;
                    tokenCurrent.strValue = strCurrentValue;
                    _return.push_back(tokenCurrent);
                    state=XML_TOKEN_STATE_ZERO;
                    iCurrentTokenType=XML_TOKEN_TYPE_INVALID;
                }else {
                    strCurrentValue.append(1, cCurrent);
                }
            }
            break;
            case XML_TOKEN_STATE_EIGHT:
            {
                char cCurrent = inXml [iCurrentPosition++] ;
                if ( cCurrent == ' ' || cCurrent == '\t' || cCurrent ==  '\n') {
                    // :DO NOTHING:
                    
                }else if ( cCurrent == '>' ){
                    tokenCurrent.iTokenType = iCurrentTokenType;
                    tokenCurrent.strValue = strCurrentValue;
                    _return.push_back( tokenCurrent);
                    state = XML_TOKEN_STATE_ZERO;
                    iCurrentTokenType = XML_TOKEN_TYPE_INVALID;
                }
                else 
                {
                    strCurrentValue.append(1, cCurrent);
                }
            }
            break;
            default:
                std::cout << "This state never can reach."<< std::endl;
                break;
            
        }
    }
    if ( state != XML_TOKEN_STATE_ZERO){
        std::cout << "xml parsing error " << std::endl;
    }
    return _return;
}


static std::string print_formatted_xml( std::vector<xml_token> vecToken)
{
    std::ostringstream oss ;
    oss.str("");
    
    int depth= 0;
    int iLastTokenType = XML_TOKEN_TYPE_INVALID ;
    
    for ( std::vector<xml_token>::iterator itr = vecToken.begin(); \
            itr != vecToken.end() ; itr++)
    {
        xml_token current_tok = *itr;
        if ( current_tok.iTokenType ==  XML_TOKEN_TYPE_START_TAG ){
            
            if( iLastTokenType == XML_TOKEN_TYPE_START_TAG || iLastTokenType == XML_TOKEN_TYPE_END_TAG )
            {
                oss << '\n' ;
            
                // whitespace to depth //
                for( int i=0; i< depth*2 ; i++){
                    oss <<' ';
                }
            }
            
            oss << "<" << current_tok.strValue << ">";
            depth++;
            iLastTokenType = XML_TOKEN_TYPE_START_TAG;
        }
        
        if ( current_tok.iTokenType == XML_TOKEN_TYPE_END_TAG )
        {
            depth--;
            if( iLastTokenType == XML_TOKEN_TYPE_START_TAG || iLastTokenType == XML_TOKEN_TYPE_END_TAG )
            {
                oss << '\n' ;
            
                // whitespace to depth //
                for( int i=0; i< depth*2 ; i++){
                    oss <<' ';
                }
            }  
            
            oss << "</"<< current_tok.strValue << ">";
            iLastTokenType = XML_TOKEN_TYPE_END_TAG;
        }
        
        if ( current_tok.iTokenType == XML_TOKEN_TYPE_DATA ){
            oss << current_tok.strValue;
            iLastTokenType = XML_TOKEN_TYPE_DATA;
        }
    }
    return oss.str();
}

std::string format_xml( std::string strInXml )
{
    std::vector<xml_token> _return  = break_xml_into_tokens(strInXml);   
    return print_formatted_xml(_return);
}
