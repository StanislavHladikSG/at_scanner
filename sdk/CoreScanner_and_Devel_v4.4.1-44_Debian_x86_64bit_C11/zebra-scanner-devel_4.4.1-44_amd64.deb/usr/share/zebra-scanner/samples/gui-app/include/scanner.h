/*   Copyright (c) 2022 Zebra Technologies - All Rights Reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *    
 *   bug me: ems.support@zebra.com
 */


#ifndef _SCANNER_H_
#define _SCANNER_H_

#include <CsUserDefs.h>
#include <string>
#include <iostream>

typedef struct tag_ScannerObj {
    int iScannerId;
    ScannerType scannerType;
    std::string  strComInterface;
    std::string  strModel;
    std::string  strFirmware;
    std::string  strBuild;
    std::string  strSerialOrPort;
    std::string  strGUID;
} Scanner;

#endif 
