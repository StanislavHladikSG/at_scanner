

/*   �2022 Zebra Technologieses LLC. All rights reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *    
 *   bug me: ems.support@zebra.com
 */

// system includes //
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <boost/thread/mutex.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/numeric/conversion/cast.hpp>



