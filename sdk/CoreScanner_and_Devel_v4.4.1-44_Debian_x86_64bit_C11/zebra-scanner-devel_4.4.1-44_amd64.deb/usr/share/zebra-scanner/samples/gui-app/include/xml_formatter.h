#ifndef __XML_FORMATTER_H_
#define __XML_FORMATTER_H_

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>

std::string format_xml(std::string strInXml);


#endif 
